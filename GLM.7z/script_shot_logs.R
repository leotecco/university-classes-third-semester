# https://www.kaggle.com/dansbecker/nba-shot-logs/download
# https://stackoverflow.com/questions/43643656/logistic-regression-on-nba-shot-data

shot_logs <- read.csv("C:/Users/Laboratorio/Desktop/nba-shot-logs/shot_logs.csv")
shot_logs <- na.omit(shot_logs)
View(shot_logs)

amostra <- sample(nrow(shot_logs), nrow(shot_logs) * .6)
amostra_ordenada <- sort(amostra)
View(amostra)

treino <- shot_logs[amostra_ordenada, ]
teste <- shot_logs[-amostra_ordenada, ]

View(treino)
View(teste)

model_shot_logs <- glm(FGM ~ LOCATION + SHOT_NUMBER + CLOSE_DEF_DIST + 
                          DRIBBLES + SHOT_CLOCK + PERIOD + TOUCH_TIME, data=treino, 
                        family="binomial", na.action = na.omit)

previsao <- predict(model_shot_logs, teste, type = "response")

previsao.formatado <- ifelse(previsao >= 0.5, 1, 0)

matriz_confusao = table(teste$FGM, previsao.formatado)
print(matriz_confusao)
